/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'fr-ca', {
	find: 'Rechercher',
	findOptions: 'Options de recherche',
	findWhat: 'Rechercher:',
	matchCase: 'Respecter la casse',
	matchCyclic: 'Recherche cyclique',
	matchWord: 'Mot entier',
	notFoundMsg: 'Le texte indiqué est introuvable.',
	replace: 'Remplacer',
	replaceAll: 'Tout remplacer',
	replaceSuccessMsg: '%1 remplacements.',
	replaceWith: 'Remplacer par:',
	title: 'Rechercher et remplacer'
} );
