/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'tr', {
	find: 'Bul',
	findOptions: 'Seçenekleri Bul',
	findWhat: 'Aranan:',
	matchCase: 'Büyük/küçük harf duyarlı',
	matchCyclic: 'Eşleşen döngü',
	matchWord: 'Kelimenin tamamı uysun',
	notFoundMsg: 'Belirtilen yazı bulunamadı.',
	replace: 'Değiştir',
	replaceAll: 'Tümünü Değiştir',
	replaceSuccessMsg: '%1 bulunanlardan değiştirildi.',
	replaceWith: 'Bununla değiştir:',
	title: 'Bul ve Değiştir'
} );
