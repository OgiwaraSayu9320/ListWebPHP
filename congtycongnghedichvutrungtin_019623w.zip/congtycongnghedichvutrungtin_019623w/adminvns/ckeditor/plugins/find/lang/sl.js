/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'sl', {
	find: 'Najdi',
	findOptions: 'Možnosti iskanja',
	findWhat: 'Najdi:',
	matchCase: 'Razlikuj velike in male črke',
	matchCyclic: 'Primerjaj znake v cirilici',
	matchWord: 'Samo cele besede',
	notFoundMsg: 'Navedenega besedila nismo našli.',
	replace: 'Zamenjaj',
	replaceAll: 'Zamenjaj vse',
	replaceSuccessMsg: 'Zamenjali smo %1 pojavitev.',
	replaceWith: 'Zamenjaj z:',
	title: 'Najdi in zamenjaj'
} );
