/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'lt', {
	find: 'Rasti',
	findOptions: 'Paieškos nustatymai',
	findWhat: 'Surasti tekstą:',
	matchCase: 'Skirti didžiąsias ir mažąsias raides',
	matchCyclic: 'Sutampantis cikliškumas',
	matchWord: 'Atitikti pilną žodį',
	notFoundMsg: 'Nurodytas tekstas nerastas.',
	replace: 'Pakeisti',
	replaceAll: 'Pakeisti viską',
	replaceSuccessMsg: '%1 sutapimas(ų) buvo pakeisti.',
	replaceWith: 'Pakeisti tekstu:',
	title: 'Surasti ir pakeisti'
} );
