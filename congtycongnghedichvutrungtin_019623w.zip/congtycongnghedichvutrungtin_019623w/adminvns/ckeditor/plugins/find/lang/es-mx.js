/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'es-mx', {
	find: 'Buscar',
	findOptions: 'Opciones de busqueda',
	findWhat: 'Buscar que:',
	matchCase: 'Comparar mayúsculas',
	matchCyclic: 'Comparación cíclica',
	matchWord: 'Compare la palabra completa',
	notFoundMsg: 'El texto especificado no fue encontrado.',
	replace: 'Remplazar',
	replaceAll: 'Remplazar todo',
	replaceSuccessMsg: '%1 ',
	replaceWith: 'Reemplazar con:',
	title: 'Busca y reemplaza'
} );
