/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'cy', {
	find: 'Chwilio',
	findOptions: 'Opsiynau Chwilio',
	findWhat: 'Chwilio\'r term:',
	matchCase: 'Cydweddu\'r cas',
	matchCyclic: 'Cydweddu\'n gylchol',
	matchWord: 'Cydweddu gair cyfan',
	notFoundMsg: 'Nid oedd y testun wedi\'i ddarganfod.',
	replace: 'Amnewid Un',
	replaceAll: 'Amnewid Pob',
	replaceSuccessMsg: 'Amnewidiwyd %1 achlysur.',
	replaceWith: 'Amnewid gyda:',
	title: 'Chwilio ac Amnewid'
} );
