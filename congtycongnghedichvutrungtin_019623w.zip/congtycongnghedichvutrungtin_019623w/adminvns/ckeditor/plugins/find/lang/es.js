/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'es', {
	find: 'Buscar',
	findOptions: 'Opciones de búsqueda',
	findWhat: 'Texto a buscar:',
	matchCase: 'Coincidir may/min',
	matchCyclic: 'Buscar en todo el contenido',
	matchWord: 'Coincidir toda la palabra',
	notFoundMsg: 'El texto especificado no ha sido encontrado.',
	replace: 'Reemplazar',
	replaceAll: 'Reemplazar Todo',
	replaceSuccessMsg: 'La expresión buscada ha sido reemplazada %1 veces.',
	replaceWith: 'Reemplazar con:',
	title: 'Buscar y Reemplazar'
} );
