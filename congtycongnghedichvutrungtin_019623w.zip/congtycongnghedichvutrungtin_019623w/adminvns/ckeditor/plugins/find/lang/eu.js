/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'eu', {
	find: 'Bilatu',
	findOptions: 'Bilaketaren aukerak',
	findWhat: 'Bilatu hau:',
	matchCase: 'Maiuskula/minuskula',
	matchCyclic: 'Bilaketa ziklikoa',
	matchWord: 'Bilatu hitz osoa',
	notFoundMsg: 'Ez da aurkitu zehazturiko testua.',
	replace: 'Ordezkatu',
	replaceAll: 'Ordezkatu guztiak',
	replaceSuccessMsg: '%1 aldiz ordezkatua.',
	replaceWith: 'Ordezkatu honekin:',
	title: 'Bilatu eta ordezkatu'
} );
