/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'ar', {
	find: 'بحث',
	findOptions: 'Find Options',
	findWhat: 'البحث بـ:',
	matchCase: 'مطابقة حالة الأحرف',
	matchCyclic: 'مطابقة دورية',
	matchWord: 'مطابقة بالكامل',
	notFoundMsg: 'لم يتم العثور على النص المحدد.',
	replace: 'إستبدال',
	replaceAll: 'إستبدال الكل',
	replaceSuccessMsg: 'تم استبدال 1% من الحالات ',
	replaceWith: 'إستبدال بـ:',
	title: 'بحث واستبدال'
} );
