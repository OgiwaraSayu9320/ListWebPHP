/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'eo', {
	find: 'Serĉi',
	findOptions: 'Opcioj pri Serĉado',
	findWhat: 'Serĉi:',
	matchCase: 'Kongruigi Usklecon',
	matchCyclic: 'Cikla Serĉado',
	matchWord: 'Tuta Vorto',
	notFoundMsg: 'La celteksto ne estas trovita.',
	replace: 'Anstataŭigi',
	replaceAll: 'Anstataŭigi Ĉion',
	replaceSuccessMsg: '%1 anstataŭigita(j) apero(j).',
	replaceWith: 'Anstataŭigi per:',
	title: 'Serĉi kaj Anstataŭigi'
} );
