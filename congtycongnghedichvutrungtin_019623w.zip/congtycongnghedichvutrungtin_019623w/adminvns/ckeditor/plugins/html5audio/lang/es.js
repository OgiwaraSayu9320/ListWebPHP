CKEDITOR.plugins.setLang( 'html5audio', 'es', {
    button: 'Insertar audio HTML5',
    title: 'Audio HTML5',
    infoLabel: 'Información del audio',
    urlMissing: 'La URL del audio no puede estar vacia.',
    audioProperties: 'Propiedades del audio',
    upload: 'Cargar',
    btnUpload: 'Enviar al servidor',
    advanced: 'Avanzado',
    autoplay: '¿Reproducir automáticamente?',
    allowdownload: '¿Permitir la descarga?',
    yes: 'Si',
    no: 'No'
} );
