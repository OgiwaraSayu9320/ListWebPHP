/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'tr', {
	label: 'Formatı Kopyala',
	notification: {
		copied: 'Formatlama Kopyalandı',
		applied: 'Formatlama Uygulandı',
		canceled: 'Formatlama İptal Edildi',
		failed: 'Formatlama hatası. İlk önce onları kopyalamadan stilleri uygulayamazsınız.'
	}
} );
