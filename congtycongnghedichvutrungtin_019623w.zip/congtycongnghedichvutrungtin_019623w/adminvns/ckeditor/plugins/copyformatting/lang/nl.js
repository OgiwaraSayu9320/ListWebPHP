/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'nl', {
	label: 'Opmaakstijl kopiëren',
	notification: {
		copied: 'Opmaakstijl gekopieerd',
		applied: 'Opmaakstijl toegepast',
		canceled: 'Opmaakstijl toepassen geannuleerd',
		failed: 'Opmaakstijl toepassen mislukt. U kunt geen opmaakstijl toepassen zonder deze eerst te kopiëren.'
	}
} );
