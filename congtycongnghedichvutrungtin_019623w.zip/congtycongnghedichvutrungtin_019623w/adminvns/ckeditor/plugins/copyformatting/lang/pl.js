/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'pl', {
	label: 'Kopiuj formatowanie',
	notification: {
		copied: 'Formatowanie skopiowane',
		applied: 'Formatowanie zastosowane',
		canceled: 'Formatowanie przerwane',
		failed: 'Formatowanie nie powiodło się. Nie możesz zastosować stylów bez uprzedniego ich skopiowania.'
	}
} );
